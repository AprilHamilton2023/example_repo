#include <fstream> //Read and write files
#include <iostream> 
#include <sstream> //Allows us to use stringstreams
#include <string> //Allows us to use string data

using namespace std;

//Start of Struct
struct dataRecord{
  //Does not have a definition outside the record 
    string JobID;
    string Agency;
    string PostingType;
    string CivilServiceTitle;
    string SalaryRangeFrom;
    string SalaryRangeTo;
}; //Always end with a semi column

//Function prototypes
bool readCSVtoArray(string, dataRecord[], int);//Reads CSV files to make arrays
 void printRecord(dataRecord); //Prints individual Records
 void print_n(dataRecord[], int); //Prints a certain number of records
 void HighestSalary(dataRecord, int); //Prints highest SalaryRangeTo

 //Project Purposes
 void LowestSalary(dataRecord[], int);//Prints the lowest SalaryRangeFrom
 void MatchingSalary(dataRecord[],dataRecord[],int,int); //Prints the MatchingSalary
 
 void CreateFile(dataRecord[],int); //Creates file and saves the results
 
int main(){
 string filename = "NYC_Jobs.csv"; 
  const int size = 1267; //creates array of data records
  dataRecord myRecords[size];//creates array of data records
  
  //Call function to read in csv data 
  if (readCSVtoArray(filename, myRecords, size)){
    cout << "Data read in successfully\n";
  }
  else{
    cout << "Couldn't read in data\n";
 }
  //Menu Options
   cout<<"Please enter a value to continue"<<endl;
   cout<<"1.Lowest Salary"<<endl;
   cout<<"2.Starting Salary"<<endl;
   cout<<"3.File Request"<<endl; //Still working on 

   int choice;
   cin>>choice;

  switch(choice)
  {
    case 1: //Lowest Salary Option
     LowestSalary(myRecords, size);
     return 0;

    case 2: //Enter Salary 
     int value;
     cout<<"Please enter a starting salary:";
     cin>>value;

     MatchingSalary(myRecords,myRecords,size,value);
     return 0;
    
    case 3: //Request files
     cout<<"Please request a number of files: ";
     int request; 
     cin>>request; 
     CreateFile(myRecords,request);
     return 0;
  }
	return 0;
}

//Functions
bool readCSVtoArray(string filename, dataRecord records[], int size){
 bool success = false; //We cannot read the file

  ifstream infile(filename, ios::in); //Opens file for reading
  string line; //Hold each line of data 

  //If file opens
  if (infile){ 
    cout << "\nFile opened\n";
    getline(infile, line); 

    for (int i = 0; i < size; i++){
      //To go through remaining rows
      getline(infile, line);

      //Goes into istringstream
      istringstream rowData{line};

      // read fields into related string of datarecord struct
      getline(rowData,records[i].JobID,','); //reads until the comma
      getline(rowData,records[i].Agency,',');
      getline(rowData,records[i].PostingType,',');
      getline(rowData,records[i].CivilServiceTitle,',');
      getline(rowData,records[i].SalaryRangeFrom, ',');
      getline(rowData,records[i].SalaryRangeTo,',');
    }
    success = true; //We are able to read the files 
  }
  return success;
}

// print a single record 
 void printRecord(dataRecord record){
  cout<<"\n\nJob ID:"<<record.JobID
  <<"\nAgency: "<<record.Agency
  <<"\nPosting Type: "<<record.PostingType
  <<"\nCivil Service Title: "<<record.CivilServiceTitle
  <<"\nSalary Range From: "<<record.SalaryRangeFrom
  <<"\nSalary Range To: "<<record.SalaryRangeTo;
}

// print number of requests on request 
 void print_n(dataRecord records[], int n){
  for (int i = 0; i < n; i++){ 
    printRecord(records[i]);
  }
}

void HighestSalary(dataRecord record[], int size){
  int position;//Saves the position in the given array
  int largest = stoi(record[0].SalaryRangeTo); //Saves the largest salary in the given array

  for (int i=0; i < size; i++){
    if(stoi(record[i].SalaryRangeTo)>largest){   
    largest = stoi(record[i].SalaryRangeTo); 
    position = i;
    }
  }
  cout<<'\n'<<'\n'<<"Highest Paying Job";
  printRecord(record[position]);
}

void LowestSalary(dataRecord record[],int size){
  int position; //Saves the position of the array
  int smallest = stoi(record[0].SalaryRangeFrom); //Saves the largest salary in the given array

  for (int i=0; i < size; i++){
    if(stoi(record[i].SalaryRangeFrom)<smallest){
      smallest = stoi(record[i].SalaryRangeFrom);
      position = i;
    }
  }
  cout<<'\n'<<'\n'<<"Lowest Paying Job";
  printRecord(record[position]);
}

void MatchingSalary(dataRecord record[],dataRecord records[], int size, int value){
  int position; //Saves the position of the array
  int matching;

  for(int i = 0; i < size ; i++){
    if(stoi(record[i].SalaryRangeFrom)>=value){
     matching = stoi(record[i].SalaryRangeFrom);
      position = i;

     cout<<'\n'<<'\n'<<"Matching Salaries: ";
     printRecord(records[i]);
    }     
  }
}

void CreateFile(dataRecord records[],int request){
 ofstream SearchHistory;//Creates the file
 SearchHistory.open("SearchHistory.csv", ios::out); //Opens file for writing

  SearchHistory<<"User Search History";
  print_n(records, request);

  for(int i = 0; i < request;i++){
   SearchHistory<<"\n\nJob ID:"<<records[i].JobID
   <<"\nAgency: "<<records[i].Agency
   <<"\nPosting Type: "<<records[i].PostingType
   <<"\nCivil Service Title: "<<records[i].CivilServiceTitle
   <<"\nSalary Range From: "<<records[i].SalaryRangeFrom
   <<"\nSalary Range To: "<<records[i].SalaryRangeTo;
  }
 SearchHistory.close(); //Closes file
}

// file.CSV = file.CommaSeparatedValue 
//stoi(arrayname[p#].field_in_record) covert string to int
